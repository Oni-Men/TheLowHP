# Thanks to download this resource set

We would like you to do utilize to flourish of our community.

このリソースセットをダウンロード頂きありがとうございます。
TheLow コミュニティ発展のために、ぜひご活用お願いします。

## 注意事項

- 大きさと配置の変更は自由ですが、素材自体の形は変えないでください。
- SVG ファイルは対応したソフトで編集/エクスポートが可能です。
- または、ブラウザで開いてスクリーンショットしても画像として利用できます。
- セットに含まれる全ての内容について、著作権は TheLow に帰属します。

## Attentions

- Don't change the shape, but you are free to scale and placement.
- SVG files are able to open with softwares which supports.
- Alternatively, you can open it with web browser and take a screenshot to use it as an image.
- All contents in this set are copyrighted by TheLow.
